import os
from langchain_community.vectorstores import FAISS
from langchain_community.embeddings import SentenceTransformerEmbeddings

# --- 保证配置与您的工具代码完全一致 ---
VECTOR_DB_DIR = os.path.join(os.path.dirname(__file__), "local_faiss_index")
EMBEDDING_MODEL = 'BAAI/bge-m3'

def run_test():
    """
    一个独立的函数，用于测试FAISS索引的搜索功能。
    """
    print("--- 开始独立测试本地向量数据库 ---")

    # 1. 检查索引目录是否存在
    if not os.path.exists(VECTOR_DB_DIR):
        print(f"错误：向量数据库目录不存在于 '{VECTOR_DB_DIR}'")
        return

    # 2. 加载嵌入模型
    print(f"正在加载嵌入模型: {EMBEDDING_MODEL}...")
    try:
        embedding_function = SentenceTransformerEmbeddings(model_name=EMBEDDING_MODEL)
    except Exception as e:
        print(f"错误：加载嵌入模型失败: {e}")
        return
    print("模型加载成功。")

    # 3. 加载本地FAISS索引
    print(f"正在从 '{VECTOR_DB_DIR}' 加载索引...")
    try:
        db = FAISS.load_local(VECTOR_DB_DIR, embedding_function, allow_dangerous_deserialization=True)
    except Exception as e:
        print(f"错误：加载FAISS索引失败: {e}")
        return
    print("索引加载成功。")

    # 4. 在这里输入您想测试的查询语句
    test_query = "华锐 1.5MW 机组 SS-2 叶轮超速刹车故障。"
    
    print(f"\n--- 正在执行搜索，查询内容：'{test_query}' ---")
    
    # 5. 执行相似度搜索
    # .similarity_search_with_score 可以返回相似度分数，分数越小越相关
    results = db.similarity_search_with_score(test_query, k=4)

    # 6. 打印结果
    if not results:
        print("\n--- 测试结果：未找到任何相关文档。---")
        print("可能的原因：")
        print("1. 您的查询语句与文档原文的语义相似度不够高。")
        print("2. 向量数据库构建时可能出现了问题，或者文档未被正确加载。")
    else:
        print("\n--- 测试成功！找到以下相关内容：---")
        for i, (doc, score) in enumerate(results):
            print(f"\n--- 结果 {i+1} (相似度分数: {score:.4f}) ---")
            print(f"来源: {doc.metadata.get('source', 'N/A')}")
            print(f"内容片段:\n---\n{doc.page_content}\n---")

if __name__ == "__main__":
    run_test()