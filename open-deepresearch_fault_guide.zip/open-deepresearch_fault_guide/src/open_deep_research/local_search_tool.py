import os
from typing import List
from langchain_core.tools import tool
from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain_community.vectorstores import FAISS
from langchain_community.embeddings import SentenceTransformerEmbeddings

# [修改] 导入所有需要的文档加载器
from langchain_community.document_loaders import (
    DirectoryLoader, 
    PyPDFLoader,
    TextLoader,
    UnstructuredWordDocumentLoader,
    UnstructuredExcelLoader,
    CSVLoader,
    UnstructuredMarkdownLoader,
    JSONLoader
)

# --- 配置 ---
KNOWLEDGE_BASE_DIR = os.path.expanduser("/Users/wxj/Documents/ifly/fault_guide/test") 
VECTOR_DB_DIR = os.path.join(os.path.dirname(__file__), "local_faiss_index")
EMBEDDING_MODEL = 'BAAI/bge-m3'

class LocalKnowledgeBase:
    """
    管理本地文档的加载、索引和检索。
    """
    def __init__(self, knowledge_dir: str, db_dir: str, model_name: str):
        self.knowledge_dir = knowledge_dir
        self.db_dir = db_dir
        self.embedding_function = SentenceTransformerEmbeddings(model_name=model_name)
        self.db = self._initialize_vector_db()

    def _initialize_vector_db(self):
        """
        初始化向量数据库。
        """
        if os.path.exists(self.db_dir):
            print(f"--- 从 {self.db_dir} 加载已存在的本地向量数据库 ---")
            return FAISS.load_local(self.db_dir, self.embedding_function, allow_dangerous_deserialization=True)
        else:
            print("--- 未找到本地向量数据库，开始构建... ---")
            return self._build_new_vector_db()

    # [修改] 重写此方法以支持多种文件类型
    def _build_new_vector_db(self):
        """
        构建一个新的向量数据库，支持多种文件格式。
        """
        if not os.path.exists(self.knowledge_dir):
            os.makedirs(self.knowledge_dir)
            raise FileNotFoundError(f"知识库目录不存在: {self.knowledge_dir}。")

        # 定义文件后缀名与加载器的映射关系
        LOADER_MAPPING = {
            ".pdf": PyPDFLoader,
            ".txt": TextLoader,
            ".md": UnstructuredMarkdownLoader,
            ".csv": CSVLoader,
            ".xlsx": UnstructuredExcelLoader,
            ".doc": UnstructuredWordDocumentLoader,
            ".docx": UnstructuredWordDocumentLoader,
            # JSONLoader需要一个jq schema来指定提取哪些内容
            # 这个默认 schema 会提取所有字符串类型的值
            ".json": lambda path: JSONLoader(path, jq_schema='.. | select(type == "string")'),
        }

        all_documents = []
        print(f"--- 开始从 {self.knowledge_dir} 加载所有支持的文档 ---")
        
        # 遍历知识库目录下的所有文件和子目录
        for dirpath, _, filenames in os.walk(self.knowledge_dir):
            for filename in filenames:
                file_ext = os.path.splitext(filename)[1].lower()
                if file_ext in LOADER_MAPPING:
                    loader_class_or_func = LOADER_MAPPING[file_ext]
                    file_path = os.path.join(dirpath, filename)
                    
                    try:
                        print(f"正在加载: {file_path}")
                        if file_ext == ".json":
                            loader = loader_class_or_func(file_path)
                        else:
                            loader = loader_class_or_func(file_path)
                        
                        documents = loader.load()
                        all_documents.extend(documents)
                    except Exception as e:
                        print(f"加载文件 {file_path} 时发生错误: {e}")

        if not all_documents:
            raise ValueError(f"在 {self.knowledge_dir} 中没有找到任何可加载的文档。")

        print(f"--- 已加载 {len(all_documents)} 个文档片段，开始分割... ---")
        text_splitter = RecursiveCharacterTextSplitter(chunk_size=1000, chunk_overlap=200)
        chunks = text_splitter.split_documents(all_documents)

        print(f"--- 创建向量索引并持久化到 {self.db_dir} ---")
        db = FAISS.from_documents(chunks, self.embedding_function)
        db.save_local(self.db_dir)
        print("--- 本地向量数据库创建成功！ ---")
        return db

    def search(self, query: str, k: int = 4) -> List[dict]:
        """
        在知识库中搜索单个查询，并返回结构化的原始结果列表。
        """
        print(f"--- 在本地知识库中搜索: '{query}' ---")
        results = self.db.similarity_search_with_score(query, k=k)
        return [
            {"source": doc.metadata.get("source", "N/A"), "content": doc.page_content, "score": float(score)}
            for doc, score in results
        ]

# --- 创建全局知识库实例 (保持不变) ---
try:
    knowledge_base_retriever = LocalKnowledgeBase(
        knowledge_dir=KNOWLEDGE_BASE_DIR,
        db_dir=VECTOR_DB_DIR,
        model_name=EMBEDDING_MODEL
    )
except (FileNotFoundError, ValueError) as e:
    print(f"*** 本地知识库初始化失败: {e} ***")
    knowledge_base_retriever = None

# --- 工具函数 (保持不变) ---
@tool
def local_knowledge_search(queries: List[str]) -> str:
    """
    在本地技术文档、内部手册和历史数据知识库中搜索信息。
    当需要查询技术规格、内部维护流程或专有数据时，应优先使用此工具。
    可以一次性接收多个查询。
    """
    if knowledge_base_retriever is None:
        return "错误: 本地知识库未初始化。请检查配置和文件路径。"
    
    all_results = {}
    for query in queries:
        try:
            results = knowledge_base_retriever.search(query)
            for res in results:
                if isinstance(res, dict) and res.get("source") and res.get("content"):
                    key = (res["source"], res["content"])
                    if key not in all_results:
                        all_results[key] = res
        except Exception as e:
            print(f"查询 '{query}' 期间发生错误: {e}")
            continue

    if not all_results:
        return "在本地知识库中未找到与任何查询相关的有用信息。"

    valid_results = [r for r in all_results.values() if isinstance(r, dict) and 'score' in r]
    sorted_results = sorted(valid_results, key=lambda x: x['score'])

    formatted_output = "从本地知识库中检索到以下综合信息:\n\n"
    for i, result in enumerate(sorted_results):
        source_info = result.get('source', '未知来源')
        content_info = result.get('content', '无内容')
        formatted_output += f"--- 相关信息 #{i+1} (来源: {source_info}) ---\n"
        formatted_output += f"内容:\n{content_info}\n\n"
    
    return formatted_output